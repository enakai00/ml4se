# ml4se
Sample scripts of "Machine Learning for Software Engineers"
